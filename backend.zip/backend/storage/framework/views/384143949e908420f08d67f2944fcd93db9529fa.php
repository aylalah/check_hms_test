<?php $__env->startComponent('mail::message'); ?>
Check HMS Account password reset link <br>

Here you lost your password, sorry for that, click the bottom button to reset your password.

<?php $__env->startComponent('mail::button', ['url' => 'http://'.$url.'./reset_password/'.$token]); ?>
Button Text
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
